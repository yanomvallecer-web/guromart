# GuroMart branding kit

Approved teal branding, October 2026. This kit matches the app's existing visual identity and the proposed teal browser/PWA icon update.

## Files

- logo-primary.svg / .png — full logo for white or warm paper backgrounds.
- logo-reversed.svg / .png — white logo for deep teal or dark backgrounds.
- logo-mark.svg / .png — standalone bag symbol.
- app-icon-192.png / app-icon-512.png — full-bleed teal, mask-safe Android/PWA icons.
- apple-touch-icon-180.png — Apple home-screen icon.
- favicon.svg / favicon.ico — browser icons, with 16, 32, 48 and 64 px ICO frames.
- brand-guide.png / .html — one-page visual reference.
- palette.json / brand-tokens.css — exact colors and typography tokens.
- Manrope and DM Sans WOFF2 files with their SIL Open Font Licenses.

## Typography

Manrope 700–800: headings; 800: wordmark. DM Sans 400–500: body; 600–700: buttons and navigation. The SVG wordmarks use outlined lettering, so no font installation is needed to display them correctly. The included WOFF2 fonts are for web use. Use the transparent PNG exports for reliable importing into Canva or presentations.

## Logo usage

Keep at least half the bag's width clear on every side. Recommended minimum full-logo width: 140 px; symbol: 24 px. Do not stretch, rotate, add shadows or recolor the logo. Use the reversed version on dark backgrounds. Keep the app icon's solid square background; the operating system applies its mask.

## Interface usage

Teal #17675F: primary buttons and links. Forest ink #213C36: headings and text. Warm paper #F7F5EF: page background. White #FFFFFF: cards. Soft sage #E7EFEA: selected and supporting surfaces. Gold #E9B44C: small highlights and ratings; avoid small gold text on white. Use the provided SVG/PNG artwork rather than tracing a screenshot.

## Deployment

Browser and home-screen icon artwork is separate from the in-page logo. The update replaces all icon formats and gives the manifest fresh icon URLs. Existing Android installations may update later than the website. A separately packaged Android launcher icon requires rebuilding its wrapper app; this repository contains the web/PWA assets.
